export { default as AddDevice } from './AddDevice';
export {default as EditDevices} from './EditDevices';
export {default as List} from './List';