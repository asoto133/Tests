Installation:
------------

```bash
$ npm install
```

Run
------------

```bash
$ npm start
```